#include<stdio.h>

int main()
{
	int chk=0x01234567;
	if(*((char*)&chk)==0x67)
		printf("Little-endian\n");
	else
		printf("Big-endian\n");
	return 0;
}
